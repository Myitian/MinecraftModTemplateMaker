package !@PKG.integration.clothconfig;

import me.shedaniel.clothconfig2.api.ConfigBuilder;
import !@PKG.!@NAME;
import !@PKG.config.Config;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.io.File;

public class ConfigScreen {
    public static Screen buildConfigScreen(Screen parent) {
        File configFile = !@NAME.CONFIG_PATH.toFile();
        Config.load(configFile);
        ConfigBuilder builder = ConfigBuilder.create()
                .setParentScreen(parent)
                .setTitle(Component.translatable("title.!@MODID.config"))
                .setSavingRunnable(() -> Config.save(configFile));
        return builder.build();
    }
}