package !@PKG.neoforge;

import !@PKG.!@NAME;
import net.neoforged.fml.common.Mod;

@Mod(!@NAME.MOD_ID)
public class !@NAMENeoForge {
    public !@NAMENeoForge() {
        !@NAME.init();
    }
}