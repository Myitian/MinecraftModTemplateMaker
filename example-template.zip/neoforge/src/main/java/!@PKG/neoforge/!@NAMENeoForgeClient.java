package !@PKG.neoforge;

import !@PKG.!@NAME;
import !@PKG.integration.clothconfig.ConfigScreen;
import net.minecraft.client.gui.screens.Screen;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.fml.IExtensionPoint;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.client.gui.IConfigScreenFactory;

import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

@Mod(value = !@NAME.MOD_ID, dist = Dist.CLIENT)
public class !@NAMENeoForgeClient {
    public !@NAMENeoForgeClient(ModContainer modContainer) {
        if (!@NAME.CLOTH_CONFIG_EXISTED) {
            try {
                Method registerExtensionPoint = ModContainer.class.getMethod(
                        "registerExtensionPoint",
                        Class.class,
                        IExtensionPoint.class);
                Class<IConfigScreenFactory> clazz = IConfigScreenFactory.class;
                //noinspection JavaReflectionInvocation
                registerExtensionPoint.invoke(modContainer, clazz, Proxy.newProxyInstance(
                        clazz.getClassLoader(),
                        new Class<?>[]{clazz},
                        (proxy, method, args) -> {
                            if ("createScreen".equals(method.getName())
                                    && args != null
                                    && args.length == 2
                                    && args[1] instanceof Screen screen) {
                                return ConfigScreen.buildConfigScreen(screen);
                            }
                            return method.invoke(proxy, args);
                        }));
                // NeoForge commit 7d465ab changes IConfigScreenFactory:
                // - Screen createScreen(Minecraft minecraft, Screen modListScreen);
                // + Screen createScreen(ModContainer container, Screen modListScreen);
            } catch (Exception ex) {
                !@NAME.LOGGER.warn("Cannot load config screen: {}", ex.getLocalizedMessage());
            }
        }
    }
}