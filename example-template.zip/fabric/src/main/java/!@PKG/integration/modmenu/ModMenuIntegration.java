package !@PKG.integration.modmenu;


import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;
import !@PKG.!@NAME;
import !@PKG.integration.clothconfig.ConfigScreen;

public final class ModMenuIntegration implements ModMenuApi {
    @Override
    public ConfigScreenFactory<?> getModConfigScreenFactory() {
        if (!@NAME.CLOTH_CONFIG_EXISTED) {
            return ConfigScreen::buildConfigScreen;
        } else {
            return parent -> null;
        }
    }
}