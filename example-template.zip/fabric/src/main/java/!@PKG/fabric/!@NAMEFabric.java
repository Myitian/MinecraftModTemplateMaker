package !@PKG.fabric;

import !@PKG.!@NAME;
import net.fabricmc.api.ClientModInitializer;

public class !@NAMEFabric implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        !@NAME.init();
    }
}