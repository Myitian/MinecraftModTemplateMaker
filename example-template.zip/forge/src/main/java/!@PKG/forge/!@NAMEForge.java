package !@PKG.forge;

import !@PKG.!@NAME;
import !@PKG.integration.clothconfig.ConfigScreen;
import net.minecraftforge.client.ConfigScreenHandler;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;

@Mod(!@NAME.MOD_ID)
public class !@NAMEForge {
    public !@NAMEForge() {
        //noinspection removal
        this(ModLoadingContext.get());
    }

    public !@NAMEForge(ModLoadingContext context) {
        !@NAME.init();
        if (!@NAME.CLOTH_CONFIG_EXISTED) {
            context.registerExtensionPoint(
                    ConfigScreenHandler.ConfigScreenFactory.class,
                    () -> new ConfigScreenHandler.ConfigScreenFactory((mc, parent) -> ConfigScreen.buildConfigScreen(parent))
            );
        }
    }
}